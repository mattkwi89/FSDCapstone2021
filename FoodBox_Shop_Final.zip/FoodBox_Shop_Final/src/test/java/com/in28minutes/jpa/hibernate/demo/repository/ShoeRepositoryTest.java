package com.in28minutes.jpa.hibernate.demo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.Subgraph;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.annotation.Transactional;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Shoe;
import com.in28minutes.jpa.hibernate.demo.entity.Review;
import com.in28minutes.jpa.hibernate.demo.entity.Customer;

@SpringBootTest(classes = DemoApplication.class)
public class ShoeRepositoryTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ShoeRepository repository;

	@Autowired
	EntityManager em;

	@Test
	public void findById_basic() {
		Shoe shoe = repository.findById(10001L);
		assertEquals("Reebok", shoe.getName());
	}
	
	@Test
	public void findById_firstLevelCacheDemo() {
		
		Shoe shoe = repository.findById(10001L);
		logger.info("First Shoe Retrieved {}", shoe);

		Shoe shoe1 = repository.findById(10001L);
		logger.info("First Shoe Retrieved again {}", shoe1);

		assertEquals("Reebok", shoe.getName());
		
		assertEquals("Reebok", shoe1.getName());
	}


	@Test
	@DirtiesContext
	public void deleteById_basic() {
		repository.deleteById(10002L);
		assertNull(repository.findById(10002L));
	}

	@Test
	@DirtiesContext
	public void save_basic() {
		// get a shoe
		Shoe shoe = repository.findById(10001L);
		assertEquals("Reebok", shoe.getName());

		// update details
		shoe.setName("Reebok - Updated");
		repository.save(shoe);

		// check the value
		Shoe shoe1 = repository.findById(10001L);
		assertEquals("Reebok - Updated", shoe1.getName());
	}

	@Test
	@DirtiesContext
	public void playWithEntityManager() {
		repository.playWithEntityManager();
	}

	@Test
	@Transactional
	public void retrieveReviewsForshoe() {
		Shoe shoe = repository.findById(10001L);
		logger.info("{}", shoe.getReviews());
	}

	@Test
	@Transactional
	public void retrieveshoeForReview() {
		Review review = em.find(Review.class, 50001L);
		logger.info("{}", review.getShoe());
	}

	@Test
	@Transactional
	@DirtiesContext
	public void performance() {
		//for (int i = 0; i < 20; i++)
			//em.persist(new Shoe("Something" + i));
		//em.flush();
		
		//EntityGraph graph = em.getEntityGraph("graph.shoeAndcustomers");
		
		EntityGraph<Shoe> graph = em.createEntityGraph(Shoe.class);
	    Subgraph<List<Customer>> bookSubGraph = graph.addSubgraph("customers");
	    
	    List<Shoe> shoes = em.createQuery("Select c from Shoe c", Shoe.class)
	        .setHint("javax.persistence.loadgraph", graph)
	        .getResultList();
	    for (Shoe shoe : shoes) {
	      System.out.println(shoe + " " + shoe.getCustomers());
	    }
	}

	@Test
	@Transactional
	@DirtiesContext
	public void performance_without_hint() {	    
	    List<Shoe> shoes = em.createQuery("Select c from Shoe c", Shoe.class)
	        //.setHint("javax.persistence.loadgraph", graph)
	        .getResultList();
	    for (Shoe shoe : shoes) {
	      System.out.println(shoe + " " + shoe.getCustomers());
	    }
	}

}
