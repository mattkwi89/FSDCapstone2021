package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Shoe;

@SpringBootTest(classes = DemoApplication.class)
public class CriteriaQueryTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EntityManager em;

	@Test
	public void all_shoes() {
		// "Select c From Shoe c"

		// 1. Use Criteria Builder to create a Criteria Query returning the
		// expected result object
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Shoe> cq = cb.createQuery(Shoe.class);

		// 2. Define roots for tables which are involved in the query
		Root<Shoe> shoeRoot = cq.from(Shoe.class);

		// 3. Define Predicates etc using Criteria Builder

		// 4. Add Predicates etc to the Criteria Query

		// 5. Build the TypedQuery using the entity manager and criteria query
		TypedQuery<Shoe> query = em.createQuery(cq.select(shoeRoot));

		List<Shoe> resultList = query.getResultList();

		logger.info("Typed Query -> {}", resultList);
		// [Shoe[Reebok], Shoe[ADIDAS], Shoe[New
		// Balance]]
	}

	@Test
	public void all_shoes_having_100Steps() {
		// "Select c From Shoe c where name like '%N' "

		// 1. Use Criteria Builder to create a Criteria Query returning the
		// expected result object
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Shoe> cq = cb.createQuery(Shoe.class);

		// 2. Define roots for tables which are involved in the query
		Root<Shoe> shoeRoot = cq.from(Shoe.class);

		// 3. Define Predicates etc using Criteria Builder
		Predicate likeN = cb.like(shoeRoot.get("name"), "%N");

		// 4. Add Predicates etc to the Criteria Query
		cq.where(likeN);

		// 5. Build the TypedQuery using the entity manager and criteria query
		TypedQuery<Shoe> query = em.createQuery(cq.select(shoeRoot));

		List<Shoe> resultList = query.getResultList();

		logger.info("Typed Query -> {}", resultList);
		// [Shoe[New Balance]]
	}

	@Test
	public void all_shoes_without_customers() {
		// "Select c From Shoe c where c.customers is empty"

		// 1. Use Criteria Builder to create a Criteria Query returning the
		// expected result object
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Shoe> cq = cb.createQuery(Shoe.class);

		// 2. Define roots for tables which are involved in the query
		Root<Shoe> shoeRoot = cq.from(Shoe.class);

		// 3. Define Predicates etc using Criteria Builder
		Predicate customersIsEmpty = cb.isEmpty(shoeRoot.get("customers"));

		// 4. Add Predicates etc to the Criteria Query
		cq.where(customersIsEmpty);

		// 5. Build the TypedQuery using the entity manager and criteria query
		TypedQuery<Shoe> query = em.createQuery(cq.select(shoeRoot));

		List<Shoe> resultList = query.getResultList();

		logger.info("Typed Query -> {}", resultList);
		// [Shoe[ADIDAS]]
	}

	@Test
	public void join() {
		// "Select c From Shoe c join c.customers s"

		// 1. Use Criteria Builder to create a Criteria Query returning the
		// expected result object
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Shoe> cq = cb.createQuery(Shoe.class);

		// 2. Define roots for tables which are involved in the query
		Root<Shoe> shoeRoot = cq.from(Shoe.class);

		// 3. Define Predicates etc using Criteria Builder
		Join<Object, Object> join = shoeRoot.join("customers");

		// 4. Add Predicates etc to the Criteria Query

		// 5. Build the TypedQuery using the entity manager and criteria query
		TypedQuery<Shoe> query = em.createQuery(cq.select(shoeRoot));

		List<Shoe> resultList = query.getResultList();

		logger.info("Typed Query -> {}", resultList);
		// [Shoe[Reebok], Shoe[Reebok], Shoe[Reebok],
		//  Shoe[New Balance]]
	}

	@Test
	public void left_join() {
		// "Select c From Shoe c left join c.customers s"

		// 1. Use Criteria Builder to create a Criteria Query returning the
		// expected result object
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Shoe> cq = cb.createQuery(Shoe.class);

		// 2. Define roots for tables which are involved in the query
		Root<Shoe> shoeRoot = cq.from(Shoe.class);

		// 3. Define Predicates etc using Criteria Builder
		Join<Object, Object> join = shoeRoot.join("customers", JoinType.LEFT);

		// 4. Add Predicates etc to the Criteria Query

		// 5. Build the TypedQuery using the entity manager and criteria query
		TypedQuery<Shoe> query = em.createQuery(cq.select(shoeRoot));

		List<Shoe> resultList = query.getResultList();

		logger.info("Typed Query -> {}", resultList);
		// [Shoe[Reebok], Shoe[Reebok], Shoe[Reebok],
		//  Shoe[ADIDAS], Shoe[New Balance]]
	}

}
