package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Shoe;
import com.in28minutes.jpa.hibernate.demo.entity.Customer;

@SpringBootTest(classes = DemoApplication.class)
public class JPQLTest {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EntityManager em;

	@Test
	public void jpql_basic() {
		Query query = em.createNamedQuery("query_get_all_shoes");
		List resultList = query.getResultList();
		logger.info("Select  c  From Shoe c -> {}", resultList);
	}

	@Test
	public void jpql_typed() {
		TypedQuery<Shoe> query = em.createNamedQuery("query_get_all_shoes", Shoe.class);

		List<Shoe> resultList = query.getResultList();

		logger.info("Select  c  From Shoe c -> {}", resultList);
	}
//look here later
	@Test
	public void jpql_where() {
		TypedQuery<Shoe> query = em.createNamedQuery("query_get_n_shoes", Shoe.class);

		List<Shoe> resultList = query.getResultList();

		logger.info("Select  c  From Shoe c where name like '%N'-> {}", resultList);
		// [Shoe[Nike], Shoe[New Balance]]
	}

	@Test
	public void jpql_shoes_without_customers() {
		TypedQuery<Shoe> query = em.createQuery("Select c from Shoe c where c.customers is empty", Shoe.class);
		List<Shoe> resultList = query.getResultList();
		logger.info("Results -> {}", resultList);
		// [Shoe[ADIDAS]]
	}

	
	@Test
	public void jpql_shoes_with_atleast_2_customers() {
		TypedQuery<Shoe> query = em.createQuery("Select c from Shoe c where size(c.customers) >= 2", Shoe.class);
		List<Shoe> resultList = query.getResultList();
		logger.info("Results -> {}", resultList);
		//[Shoe[Reebok]]
	}

	@Test
	public void jpql_shoes_ordered_by_customers() {
		TypedQuery<Shoe> query = em.createQuery("Select c from Shoe c order by size(c.customers) desc", Shoe.class);
		List<Shoe> resultList = query.getResultList();
		logger.info("Results -> {}", resultList);
	}

	@Test
	public void jpql_customers_with_passports_in_a_certain_pattern() {
		TypedQuery<Customer> query = em.createQuery("Select s from Customer s where s.passport.number like '%1234%'", Customer.class);
		List<Customer> resultList = query.getResultList();
		logger.info("Results -> {}", resultList);
	}

	//like
	//BETWEEN 100 and 1000
	//IS NULL
	//upper, lower, trim, length
	
	//JOIN => Select c, s from Shoe c JOIN c.customers s
	//LEFT JOIN => Select c, s from Shoe c LEFT JOIN c.customers s
	//CROSS JOIN => Select c, s from Shoe c, Customer s
	//3 and 4 =>3 * 4 = 12 Rows
	@Test
	public void join(){
		Query query = em.createQuery("Select c, s from Shoe c JOIN c.customers s");
		List<Object[]> resultList = query.getResultList();
		logger.info("Results Size -> {}", resultList.size());
		for(Object[] result:resultList){
			logger.info("Shoe{} Customer{}", result[0], result[1]);
		}
	}

	@Test
	public void left_join(){
		Query query = em.createQuery("Select c, s from Shoe c LEFT JOIN c.customers s");
		List<Object[]> resultList = query.getResultList();
		logger.info("Results Size -> {}", resultList.size());
		for(Object[] result:resultList){
			logger.info("Shoe{} Customer{}", result[0], result[1]);
		}
	}

	@Test
	public void cross_join(){
		Query query = em.createQuery("Select c, s from Shoe c, Customer s");
		List<Object[]> resultList = query.getResultList();
		logger.info("Results Size -> {}", resultList.size());
		for(Object[] result:resultList){
			logger.info("Shoe{} Customer{}", result[0], result[1]);
		}
	}

}








