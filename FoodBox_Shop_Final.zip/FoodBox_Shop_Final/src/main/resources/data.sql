insert into shoe(id, name, created_date, last_updated_date,is_deleted) 
values(10001,'Reebok', sysdate(), sysdate(),false);
insert into shoe(id, name, created_date, last_updated_date,is_deleted) 
values(10002,'ADIDAS', sysdate(), sysdate(),false);
insert into shoe(id, name, created_date, last_updated_date,is_deleted) 
values(10003,'New Balance', sysdate(), sysdate(),false);


insert into passport(id,number)
values(40001,'E123456');
insert into passport(id,number)
values(40002,'N123457');
insert into passport(id,number)
values(40003,'L123890');

insert into customer(id,name,passport_id)
values(20001,'Ranga',40001);
insert into customer(id,name,passport_id)
values(20002,'Adam',40002);
insert into customer(id,name,passport_id)
values(20003,'Jane',40003);

insert into review(id,rating,description,shoe_id)
values(50001,'FIVE', 'Great shoe',10001);
insert into review(id,rating,description,shoe_id)
values(50002,'FOUR', 'Wonderful shoe',10001);
insert into review(id,rating,description,shoe_id)
values(50003,'FIVE', 'Awesome shoe',10003);

insert into customer_shoe(customer_id,shoe_id)
values(20001,10001);
insert into customer_shoe(customer_id,shoe_id)
values(20002,10001);
insert into customer_shoe(customer_id,shoe_id)
values(20003,10001);
insert into customer_shoe(customer_id,shoe_id)
values(20001,10003);