package com.in28minutes.jpa.hibernate.demo.repository;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.in28minutes.jpa.hibernate.demo.entity.Shoe;
import com.in28minutes.jpa.hibernate.demo.entity.Passport;
import com.in28minutes.jpa.hibernate.demo.entity.Customer;

@Repository
@Transactional
public class CustomerRepository {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;

	public Customer findById(Long id) {
		return em.find(Customer.class, id);
	}

	public Customer save(Customer customer) {

		if (customer.getId() == null) {
			em.persist(customer);
		} else {
			em.merge(customer);
		}

		return customer;
	}

	public void deleteById(Long id) {
		Customer customer = findById(id);
		em.remove(customer);
	}

	public void savecustomerWithPassport() {
		Passport passport = new Passport("Z123456");
		em.persist(passport);

		Customer customer = new Customer("Mike");

		customer.setPassport(passport);
		em.persist(customer);	
	}
	
	public void someOperationToUnderstandPersistenceContext() {
		//Database Operation 1 - Retrieve customer
		Customer customer = em.find(Customer.class, 20001L);
		//Persistence Context (customer)
		
		
		//Database Operation 2 - Retrieve passport
		Passport passport = customer.getPassport();
		//Persistence Context (customer, passport)

		//Database Operation 3 - update passport
		passport.setNumber("E123457");
		//Persistence Context (customer, passport++)
		
		//Database Operation 4 - update customer
		customer.setName("Ranga - updated");
		//Persistence Context (customer++ , passport++)
	}
	
	public void insertHardcodedcustomerAndshoe(){
		Customer customer = new Customer("Jack");
		Shoe shoe = new Shoe("Jordans");
		em.persist(customer);
		em.persist(shoe);
		
		customer.addShoe(shoe);
		shoe.addCustomer(customer);
		em.persist(customer);
	}

	public void insertCustomerAndShoe(Customer customer, Shoe shoe){
		//Customer customer = new Customer("Jack");
		//Shoe shoe = new Shoe("Jordans");
		customer.addShoe(shoe);
		shoe.addCustomer(customer);

		em.persist(customer);
		em.persist(shoe);
	}

}
