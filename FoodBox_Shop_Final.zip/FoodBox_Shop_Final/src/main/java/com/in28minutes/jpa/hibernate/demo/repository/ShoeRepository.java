package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.in28minutes.jpa.hibernate.demo.entity.Shoe;
import com.in28minutes.jpa.hibernate.demo.entity.Review;
import com.in28minutes.jpa.hibernate.demo.entity.ReviewRating;

@Repository
@Transactional
public class ShoeRepository {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private EntityManager em;

	public Shoe findById(Long id) {
		Shoe shoe = em.find(Shoe.class, id);
		logger.info("Shoe -> {}", shoe);
		return shoe;
	}

	public Shoe save(Shoe shoe) {

		if (shoe.getId() == null) {
			em.persist(shoe);
		} else {
			em.merge(shoe);
		}

		return shoe;
	}

	public void deleteById(Long id) {
		Shoe shoe = findById(id);
		em.remove(shoe);
	}

	public void playWithEntityManager() {
		Shoe shoe1 = new Shoe("Nike");
		em.persist(shoe1);
		
		Shoe shoe2 = findById(10001L);
		
		shoe2.setName("Reebok - Updated");
		
	}

	public void addHardcodedReviewsForshoe() {
		//get the shoe 10003
		Shoe shoe = findById(10003L);
		logger.info("shoe.getReviews() -> {}", shoe.getReviews());
		
		//add 2 reviews to it
		Review review1 = new Review(ReviewRating.FIVE, "Great Hands-on Stuff.");	
		Review review2 = new Review(ReviewRating.FIVE, "Hatsoff.");
		
		//setting the relationship
		shoe.addReview(review1);
		review1.setShoe(shoe);
		
		shoe.addReview(review2);
		review2.setShoe(shoe);
		
		//save it to the database
		em.persist(review1);
		em.persist(review2);
	}
	
	public void addReviewsForshoe(Long shoeId, List<Review> reviews) {		
		Shoe shoe = findById(shoeId);
		logger.info("shoe.getReviews() -> {}", shoe.getReviews());
		for(Review review:reviews)
		{			
			//setting the relationship
			shoe.addReview(review);
			review.setShoe(shoe);
			em.persist(review);
		}
	}
}